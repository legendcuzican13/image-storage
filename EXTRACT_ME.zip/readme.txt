Use the correct jar for your server version!

Minecraft version   Java version    SSX jar file
1.7.10-1.12.2       8               ServerSelectorX-3.7.2-legacy.jar
1.13.2+             11 or higher    ServerSelectorX-3.7.2.jar
